import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'player-detail',
  templateUrl: './player-detail.component.html',
  styleUrls: ['./player-detail.component.css'],
  inputs: ['player']
})
export class PlayerDetailComponent implements OnInit {

  private editPlayer: boolean = false;

  constructor() { }

  ngOnInit() {
  }

  ngOnChanges()
  {
    this.editPlayer = false;
  }

  onPlayerClick()
  {
    this.editPlayer = true;
  }

}
