import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { Player } from '../player';

@Component({
  selector: 'player-list',
  templateUrl: './player-list.component.html',
  styleUrls: ['./player-list.component.css'],
  inputs: ['players'],   //inputs is players array from player-center.ts
  outputs: ['SelectPlayer']
})
export class PlayerListComponent implements OnInit {

  public SelectPlayer = new EventEmitter();

  constructor() { }

  ngOnInit() {
  }

  onSelect(play: Player)
  {
    this.SelectPlayer.emit(play);
  }

}
