/*import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { map } from 'rxjs/operators';
import { Component } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PlayerService {

  private _getUrl = "/api/players";

  constructor(private _http: Http) { }

  getPlayers()
    {
      return this._http.get(this._getUrl)
       .pipe(map((response)=> response)); 
    }

}*/
