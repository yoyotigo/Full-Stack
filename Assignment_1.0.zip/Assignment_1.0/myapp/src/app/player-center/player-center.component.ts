import { Component, OnInit } from '@angular/core';
import { Player } from '../player';
import { PlayerService } from '../player.service';

@Component({
  selector: 'app-player-center',
  templateUrl: './player-center.component.html',
  styleUrls: ['./player-center.component.css'],
  providers: [PlayerService]
})
export class PlayerCenterComponent implements OnInit {

  players: Array<Player>; //players is array of type player

  selectedPlayer: Player;

  constructor(private _playerService: PlayerService) { }  //dependancy injection to get playerservice

  ngOnInit() 
  {
    this._playerService.getPlayers()
    .subscribe(resPlayerData => this.players = resPlayerData);
  }

  onSelectPlayer(player:any)
  {
    this.selectedPlayer = player;
    console.log(this.selectedPlayer);
  }

}
