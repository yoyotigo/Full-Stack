import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable({
  providedIn: 'root'
})
export class PlayerService {

  private _getUrl = "/api/videos";

  constructor(private _http: Http) { }  //instance of http to make requests

  getPlayers()
  {
    return this._http.get(this._getUrl)           //call get method passing the url and fetch all players
    .map((response: Response)=> response.json());  //response is mapped to json
  }
}