export class Player {
    _id: string;
    player: string;
    rank: number;
    score: number;
    time: string;
    gamesPlayed: string;
    status: string;
}
