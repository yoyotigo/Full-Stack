# COMP3123

By: Tiago Sa 101054051 & Nickolas Di Domenico 

Admin User:

Admin Password:


TO RUN THIS PROJECT DO THE FOLLOWING:

npm install

npm install express

npm install cors --save

npm install mongoose

npm update
