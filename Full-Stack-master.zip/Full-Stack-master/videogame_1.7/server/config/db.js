module.exports = {
    DB: 'mongodb://ncoder:ndmtnodm123@ds263493.mlab.com:63493/user'
 };