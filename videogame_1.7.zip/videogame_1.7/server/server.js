const express = require('express'),
      cors = require('cors'),
      mongoose = require('mongoose'),
      config = require('./config/db');
      playerRoutes = require('./routes/playerRoutes');
      gameRoutes=require('./routes/gamesRoutes');
const app = express();      


// Connect to Mongoose      
mongoose.Promise = global.Promise;
mongoose.connect(config.DB).then(
    () => {console.log('Database is connected') },
    err => { console.log('Can not connect to the database'+ err)}
  );

       
// Post Data
const bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: true }));


// Endpoint to get current user
app.get('/user', function(req, res){
  res.send(req.user);
});

/*
// Endpoint to logout
app.get('/logout', function(req, res){
  req.logout();
  res.send(null)
});*/



app.use(bodyParser.json());
app.use(cors());
const port = process.env.PORT || 4000;
app.use('/players', playerRoutes);
app.use('/games', gameRoutes);
app.listen(port, function(){
  console.log('Listening on port ' + port);
});

